$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:7860/")
$listener.Start()
Write-Host "MedTranslate Web Server listening on http://localhost:7860/ ..."

$htmlPath = "C:\Users\Support\.gemini\antigravity\brain\88c029bb-e885-4eb0-b175-88aca96ed51f\medtranslate_app.html"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $response = $context.Response
        
        if (Test-Path $htmlPath) {
            $bytes = [System.IO.File]::ReadAllBytes($htmlPath)
            $response.ContentType = "text/html; charset=utf-8"
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $msg = [System.Text.Encoding]::UTF8.GetBytes("File not found.")
            $response.StatusCode = 404
            $response.OutputStream.Write($msg, 0, $msg.Length)
        }
        $response.OutputStream.Close()
    } catch {
        break
    }
}
